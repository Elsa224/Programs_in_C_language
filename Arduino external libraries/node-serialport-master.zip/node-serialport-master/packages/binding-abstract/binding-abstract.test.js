/* eslint-disable no-new */

const BindingAbstract = require('./binding-abstract')

describe('BindingAbstract', () => {
  it('constructs', () => {
    new BindingAbstract({})
  })
})
