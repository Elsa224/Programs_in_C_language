/* eslint-disable no-new */

const BindingMock = require('./binding-mock')

describe('BindingMock', () => {
  it('constructs', () => {
    new BindingMock({})
  })
  it('needs more testing')
})
