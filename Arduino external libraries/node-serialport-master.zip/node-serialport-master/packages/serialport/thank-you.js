const message =
  '\u001b[96m\u001b[1mThank you for using serialport!\u001b[96m\u001b[1m\n\u001b[0m\u001b[96mIf you rely on this package, please consider supporting our open collective:\u001b[22m\u001b[39m\n> \u001b[94mhttps://opencollective.com/serialport-monorepo/donate\u001b[0m\n\n'
console.log(message)
