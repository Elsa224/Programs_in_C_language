---
name: 📚 Documentation
about: Report an issue related to documentation
---

## 📚 Documentation

(A clear and concise description of how the docs could be better, with links if possible)

### Have you read the [Contributing Guidelines on docs](https://github.com/serialport/node-serialport/blob/master/CONTRIBUTING.md#writing-documentation)?

(Write your answer here.)
